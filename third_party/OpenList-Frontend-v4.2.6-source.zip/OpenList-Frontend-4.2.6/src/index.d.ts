declare module "aplayer"
