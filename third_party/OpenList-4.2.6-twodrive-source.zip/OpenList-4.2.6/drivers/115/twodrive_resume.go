package _115

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/OpenListTeam/OpenList/v4/internal/driver"
	"github.com/OpenListTeam/OpenList/v4/internal/model"
	netutil "github.com/OpenListTeam/OpenList/v4/internal/net"
	resume "github.com/OpenListTeam/OpenList/v4/internal/twodrive_resume"
	"github.com/OpenListTeam/OpenList/v4/pkg/utils"
	driver115 "github.com/SheltonZhu/115driver/pkg/driver"
	"github.com/aliyun/aliyun-oss-go-sdk/oss"
)

func (d *Pan115) transferIdentity() string {
	if os.Getenv("TWODRIVE_RESUME") == "" || d.MountPath != "/115" || d.Remark != "Managed by TwoDrive" {
		return ""
	}
	for _, field := range strings.Split(d.Cookie, ";") {
		k, v, ok := strings.Cut(strings.TrimSpace(field), "=")
		if ok && k == "UID" && v != "" {
			return resume.Key(strconv.FormatUint(uint64(d.ID), 10), d.RootFolderID, strings.Split(v, "_")[0])
		}
	}
	return ""
}

func getResumeStore() (*resume.Store, error) {
	return resume.EnvironmentStore()
}

func (d *Pan115) resumableLink(file model.Obj, link *model.Link, userAgent string) error {
	identity := d.transferIdentity()
	hash := strings.ToUpper(file.GetHash().GetHash(utils.SHA1))
	if identity == "" || !twoDriveUserAgent(userAgent) || file.GetSize() < 16<<20 || len(hash) != 40 {
		return nil
	}
	s, err := getResumeStore()
	if err != nil {
		return err
	}
	key := resume.Key(identity, file.GetID(), hash, strconv.FormatInt(file.GetSize(), 10))
	url := link.URL
	header := link.Header.Clone()
	if header == nil {
		header = make(http.Header)
	}
	header.Set("User-Agent", userAgent)
	link.RangeReader = &resume.Download{
		Store: s, Key: key, Size: file.GetSize(),
		Progress: resume.NewProgress(s, userAgent, key, file.GetName(), "download", file.GetSize()),
		Fetch: func(ctx context.Context, start, length int64) (io.ReadCloser, error) {
			h := header.Clone()
			h.Set("Range", fmt.Sprintf("bytes=%d-%d", start, start+length-1))
			h.Set("Accept-Encoding", "identity")
			response, err := netutil.RequestHttp(ctx, "GET", h, url)
			if err != nil {
				return nil, err
			}
			// A 200 response would silently redownload the prefix. Refuse it.
			expected := fmt.Sprintf("bytes %d-%d/%d", start, start+length-1, file.GetSize())
			if response.StatusCode != http.StatusPartialContent || response.Header.Get("Content-Range") != expected {
				response.Body.Close()
				return nil, fmt.Errorf("download server did not honor the requested resume range")
			}
			return response.Body, nil
		},
	}
	return nil
}

func twoDriveUserAgent(ua string) bool {
	return strings.HasPrefix(ua, "TwoDrive/") || strings.Contains(ua, " TwoDrive/")
}

type uploadCheckpoint struct {
	Version     int                               `json:"version"`
	Key         string                            `json:"key"`
	Updated     int64                             `json:"updated"`
	Size        int64                             `json:"size"`
	SHA1        string                            `json:"sha1"`
	Params      driver115.UploadOSSParams         `json:"params"`
	Session     oss.InitiateMultipartUploadResult `json:"session"`
	Parts       []oss.UploadPart                  `json:"parts"`
	PartSize    int64                             `json:"part_size"`
	ReusedBytes int64                             `json:"reused_bytes"`
	SentBytes   int64                             `json:"sent_bytes"`
}

type multipartBackend interface {
	Initiate(context.Context, *driver115.UploadOSSParams) (oss.InitiateMultipartUploadResult, error)
	List(context.Context, oss.InitiateMultipartUploadResult) ([]oss.UploadedPart, error)
	Upload(context.Context, oss.InitiateMultipartUploadResult, *driver115.UploadOSSParams, io.Reader, int64, int) (oss.UploadPart, error)
	Complete(context.Context, oss.InitiateMultipartUploadResult, *driver115.UploadOSSParams, []oss.UploadPart) (*UploadResult, error)
}

func missingUpload(err error) bool {
	var e oss.ServiceError
	return errors.As(err, &e) && e.Code == "NoSuchUpload"
}

// Source SHA1 is recomputed before opening this record. Destination, account,
// content and chunk geometry are all in its identity. Only server-acknowledged
// parts are skipped; a process death before recording an ACK is reconciled
// with ListParts and the corresponding local chunk's MD5.
func runMultipart(ctx context.Context, store *resume.Store, key, sha1 string, size int64,
	source io.ReaderAt, backend multipartBackend, init func() (*driver115.UploadOSSParams, *UploadResult, error),
	up driver.UpdateProgress) (*UploadResult, error) {
	release := store.Lease()
	defer release()
	unlock := store.Lock("upload-" + key)
	defer unlock()
	filename := "u-" + key + ".json"
	chunks, err := SplitFile(size)
	if err != nil {
		return nil, err
	}
	rec := uploadCheckpoint{}
	err = store.Read(filename, &rec)
	fresh := os.IsNotExist(err)
	if err != nil && !fresh {
		return nil, err
	}
	if !fresh {
		if rec.Version != 1 || rec.Key != key || rec.SHA1 != sha1 || rec.Size != size || rec.PartSize != chunks[0].Size ||
			rec.Session.UploadID == "" || rec.Session.Key != rec.Params.Object || rec.Session.Bucket != rec.Params.Bucket ||
			len(rec.Parts) > len(chunks) {
			return nil, fmt.Errorf("upload checkpoint identity mismatch")
		}
		for i, p := range rec.Parts {
			if p.PartNumber != i+1 || p.ETag == "" {
				return nil, fmt.Errorf("invalid upload checkpoint parts")
			}
		}
		var saved int64
		for i := range rec.Parts {
			saved += chunks[i].Size
		}
		resume.ProgressFrom(ctx).Saved(saved)
		remote, e := backend.List(ctx, rec.Session)
		if missingUpload(e) {
			// Session is gone (including completion immediately before a crash).
			// Re-run 115's SHA1 rapid-upload probe before sending any file bytes.
			if e = store.Remove(filename); e != nil {
				return nil, e
			}
			fresh = true
		} else if e != nil {
			return nil, e // Network/auth errors must never silently restart at zero.
		} else {
			if len(remote) > len(chunks) {
				return nil, fmt.Errorf("unexpected remote multipart count")
			}
			parts := make([]oss.UploadPart, 0, len(remote))
			for i, p := range remote {
				ch := chunks[i]
				if p.PartNumber != ch.Number || int64(p.Size) != ch.Size {
					return nil, fmt.Errorf("remote multipart geometry changed")
				}
				h := md5.New()
				if _, e = io.CopyN(h, io.NewSectionReader(source, ch.Offset, ch.Size), ch.Size); e != nil {
					return nil, e
				}
				expected := hex.EncodeToString(h.Sum(nil))
				if !strings.EqualFold(strings.Trim(p.ETag, `"`), expected) {
					return nil, fmt.Errorf("remote multipart content changed")
				}
				if i < len(rec.Parts) && rec.Parts[i].ETag != p.ETag {
					return nil, fmt.Errorf("remote multipart acknowledgement changed")
				}
				parts = append(parts, oss.UploadPart{PartNumber: p.PartNumber, ETag: p.ETag})
			}
			rec.Parts = parts
		}
	}
	if fresh {
		params, fast, e := init()
		if e != nil || fast != nil {
			return fast, e
		}
		session, e := backend.Initiate(ctx, params)
		if e != nil {
			return nil, e
		}
		rec = uploadCheckpoint{Version: 1, Key: key, Size: size, SHA1: sha1, Params: *params, Session: session, PartSize: chunks[0].Size}
	}
	rec.Params.SHA1 = sha1 // The SDK intentionally omits this field from JSON.
	rec.SentBytes = 0
	rec.ReusedBytes = 0
	for i := 0; i < len(rec.Parts); i++ {
		rec.ReusedBytes += chunks[i].Size
	}
	rec.Updated = time.Now().Unix()
	if err = store.Write(filename, rec); err != nil {
		return nil, err
	}
	progress := resume.ProgressFrom(ctx)
	progress.Begin(rec.ReusedBytes)
	up(float64(rec.ReusedBytes) * 100 / float64(size))
	for i := len(rec.Parts); i < len(chunks); i++ {
		ch := chunks[i]
		if err = ctx.Err(); err != nil {
			return nil, err
		}
		part, e := backend.Upload(ctx, rec.Session, &rec.Params, io.NewSectionReader(source, ch.Offset, ch.Size), ch.Size, ch.Number)
		if e != nil {
			return nil, e
		} // Keep checkpoint. Retry reconciles ambiguous ACK.
		rec.Parts = append(rec.Parts, part)
		rec.SentBytes += ch.Size
		rec.Updated = time.Now().Unix()
		if err = store.Write(filename, rec); err != nil {
			return nil, err
		}
		progress.Checkpoint(rec.ReusedBytes + rec.SentBytes)
		up(float64(rec.ReusedBytes+rec.SentBytes) * 100 / float64(size))
	}
	progress.Checking("分片已传完，正在确认网盘文件")
	result, err := backend.Complete(ctx, rec.Session, &rec.Params, rec.Parts)
	if err != nil {
		return nil, err
	}
	// Keep a small, credential-free verification record, not the callback/token.
	summary := map[string]any{"version": 1, "key": key, "updated": time.Now().Unix(), "complete": true,
		"size": size, "reused_bytes": rec.ReusedBytes, "sent_bytes": rec.SentBytes}
	// Distinct key avoids ever interpreting a completed summary as a session.
	if err = store.Write("u-"+resume.Key("finished", key)+".json", summaryWithKey(summary, resume.Key("finished", key))); err != nil {
		return nil, err
	}
	if err = store.Remove(filename); err != nil {
		return nil, err
	}
	return result, nil
}

func summaryWithKey(v map[string]any, key string) map[string]any { v["key"] = key; return v }

type ossResumeBackend struct {
	driver    *Pan115
	token     *driver115.UploadOSSTokenResp
	client    *oss.Client
	refreshed time.Time
}

func (b *ossResumeBackend) bucket(name string) (*oss.Bucket, error) {
	if b.client == nil || time.Since(b.refreshed) > 45*time.Minute {
		token, err := b.driver.client.GetOSSToken()
		if err != nil {
			return nil, err
		}
		client, err := netutil.NewOSSClient(driver115.OSSEndpoint, token.AccessKeyID, token.AccessKeySecret, oss.EnableMD5(true), oss.EnableCRC(true))
		if err != nil {
			return nil, err
		}
		b.client, b.token, b.refreshed = client, token, time.Now()
	}
	return b.client.Bucket(name)
}
func (b *ossResumeBackend) options(ctx context.Context) []oss.Option {
	return []oss.Option{oss.SetHeader(driver115.OssSecurityTokenHeaderName, b.token.SecurityToken), oss.UserAgentHeader(driver115.OSSUserAgent), oss.WithContext(ctx)}
}
func (b *ossResumeBackend) Initiate(ctx context.Context, p *driver115.UploadOSSParams) (oss.InitiateMultipartUploadResult, error) {
	bucket, err := b.bucket(p.Bucket)
	if err != nil {
		return oss.InitiateMultipartUploadResult{}, err
	}
	return bucket.InitiateMultipartUpload(p.Object, append(b.options(ctx), oss.EnableSha1(), oss.Sequential())...)
}
func (b *ossResumeBackend) List(ctx context.Context, s oss.InitiateMultipartUploadResult) ([]oss.UploadedPart, error) {
	bucket, err := b.bucket(s.Bucket)
	if err != nil {
		return nil, err
	}
	var parts []oss.UploadedPart
	marker := 0
	for {
		page, err := bucket.ListUploadedParts(s, append(b.options(ctx), oss.PartNumberMarker(marker), oss.MaxParts(1000))...)
		if err != nil {
			return nil, err
		}
		parts = append(parts, page.UploadedParts...)
		if !page.IsTruncated {
			return parts, nil
		}
		next, err := strconv.Atoi(page.NextPartNumberMarker)
		if err != nil || next <= marker {
			return nil, fmt.Errorf("invalid multipart pagination")
		}
		marker = next
	}
}
func (b *ossResumeBackend) Upload(ctx context.Context, s oss.InitiateMultipartUploadResult, p *driver115.UploadOSSParams, r io.Reader, size int64, number int) (oss.UploadPart, error) {
	bucket, err := b.bucket(s.Bucket)
	if err != nil {
		return oss.UploadPart{}, err
	}
	return bucket.UploadPart(s, driver.NewLimitedUploadStream(ctx, r), size, number, append(driver115.OssOption(p, b.token), oss.WithContext(ctx))...)
}
func (b *ossResumeBackend) Complete(ctx context.Context, s oss.InitiateMultipartUploadResult, p *driver115.UploadOSSParams, parts []oss.UploadPart) (*UploadResult, error) {
	bucket, err := b.bucket(s.Bucket)
	if err != nil {
		return nil, err
	}
	var body []byte
	_, err = bucket.CompleteMultipartUpload(s, parts, append(driver115.OssOption(p, b.token), oss.WithContext(ctx), oss.CallbackResult(&body))...)
	if err != nil {
		return nil, err
	}
	var result UploadResult
	if err = json.Unmarshal(body, &result); err != nil {
		return nil, err
	}
	return &result, result.Err(string(body))
}

func (d *Pan115) resumableUpload(ctx context.Context, s model.FileStreamer, dirID, preHash, sha1 string, up driver.UpdateProgress) (model.Obj, error) {
	store, err := getResumeStore()
	if err != nil {
		return nil, err
	}
	source, err := s.CacheFullAndWriter(&up, nil)
	if err != nil {
		return nil, err
	}
	key := resume.Key(d.transferIdentity(), dirID, s.GetName(), sha1, strconv.FormatInt(s.GetSize(), 10))
	var rapidObject model.Obj
	result, err := runMultipart(ctx, store, key, sha1, s.GetSize(), source, &ossResumeBackend{driver: d}, func() (*driver115.UploadOSSParams, *UploadResult, error) {
		info, e := d.rapidUpload(s.GetSize(), s.GetName(), dirID, preHash, sha1, s)
		if e != nil {
			return nil, nil, e
		}
		matched, e := info.Ok()
		if e != nil {
			return nil, nil, e
		}
		if matched {
			rapidObject, e = d.getNewFileByPickCode(info.PickCode)
			return nil, &UploadResult{}, e
		}
		return &info.UploadOSSParams, nil, nil
	}, up)
	if err != nil {
		return nil, err
	}
	if rapidObject != nil {
		return rapidObject, nil
	}
	return d.getNewFile(result.Data.FileID)
}
