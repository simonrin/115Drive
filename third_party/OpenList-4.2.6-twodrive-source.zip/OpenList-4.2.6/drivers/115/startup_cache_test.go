package _115

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/OpenListTeam/OpenList/v4/internal/model"
)

func testStartupDriver(t *testing.T) (*Pan115, map[string]any, func()) {
	t.Helper()
	path := filepath.Join(t.TempDir(), "index.json")
	t.Setenv("TWODRIVE_VERIFIED_INDEX", path)
	d := &Pan115{Storage: model.Storage{ID: 1, MountPath: "/115", Remark: "Managed by TwoDrive"}}
	d.Cookie = "test-cookie"
	d.startupCache = newVerifiedStartupCache()
	d.startupCache.started = time.Now().Add(-time.Second)
	h := sha256.Sum256([]byte("1test-cookie"))
	idx := map[string]any{"version": 2, "remote": "cloud115:115Drive", "root_id": "1", "identity": hex.EncodeToString(h[:]), "tree_verified": true, "checked_at": float64(time.Now().UnixMilli()) / 1000,
		"dirs": map[string]any{"1": map[string]any{"path": "115Drive", "rows": []any{map[string]any{"fid": "10", "cid": "1", "n": "test.txt", "s": 7, "sha": "0123456789012345678901234567890123456789", "pc": "download-code", "tp": 100, "t": "2026-10-20 10:00"}}}}}
	write := func() {
		data, err := json.Marshal(idx)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(path, data, 0600); err != nil {
			t.Fatal(err)
		}
	}
	write()
	return d, idx, write
}

func TestTwoDriveVerifiedStartupRestoresTypedFilesOnce(t *testing.T) {
	d, _, _ := testStartupDriver(t)
	rows, ok := d.restoreVerifiedDirectory("1", false)
	if !ok || len(rows) != 1 {
		t.Fatal("did not restore complete directory")
	}
	f, ok := rows[0].(*FileObj)
	if !ok || f.PickCode != "download-code" || f.ParentID != "1" || f.Size != 7 {
		t.Fatal("driver identity/download fields lost")
	}
	if _, ok = d.restoreVerifiedDirectory("1", false); ok {
		t.Fatal("restored twice after potential invalidation")
	}
}

func TestTwoDriveVerifiedStartupRejectsUnsafeSnapshots(t *testing.T) {
	for _, mode := range []string{"old-process", "expired", "future", "wrong-account", "legacy", "unverified", "other-root", "refresh", "mutation"} {
		t.Run(mode, func(t *testing.T) {
			d, idx, write := testStartupDriver(t)
			switch mode {
			case "old-process":
				d.startupCache.started = time.Now().Add(time.Second)
			case "expired":
				idx["checked_at"] = float64(time.Now().Add(-3 * time.Minute).Unix())
				d.startupCache.started = time.Now().Add(-time.Hour)
			case "future":
				idx["checked_at"] = float64(time.Now().Add(time.Minute).Unix())
			case "wrong-account":
				d.Cookie = "another-account"
			case "legacy":
				idx["version"] = 1
			case "unverified":
				idx["tree_verified"] = false
			case "other-root":
				idx["remote"] = "cloud115:other"
			case "refresh":
				d.restoreVerifiedDirectory("1", true)
			case "mutation":
				d.disableStartupCache()
			}
			write()
			if _, ok := d.restoreVerifiedDirectory("1", false); ok {
				t.Fatal("unsafe snapshot accepted")
			}
		})
	}
}
