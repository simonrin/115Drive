package _115

import (
	"github.com/OpenListTeam/OpenList/v4/pkg/utils"
	"testing"
)

func TestTwoDriveLargerUploadParts(t *testing.T) {
	sizes := []int64{1, 10*utils.MB + 1, 128 * utils.MB, 8 * utils.GB,
		8 * utils.MB * 9999, 8 * utils.MB * 10000, 256 * utils.GB, 1024 * utils.GB}
	for _, size := range sizes {
		parts, err := SplitFile(size)
		if err != nil {
			t.Fatalf("size %d: %v", size, err)
		}
		if len(parts) == 0 || len(parts) > 9999 {
			t.Fatalf("size %d: invalid parts %d", size, len(parts))
		}
		var offset int64
		for index, part := range parts {
			if part.Offset != offset || part.Number != index+1 || part.Size <= 0 {
				t.Fatalf("size %d: discontinuity in part %d", size, index)
			}
			if index < len(parts)-1 && part.Size < 100*utils.KB {
				t.Fatal("nonfinal part too small")
			}
			offset += part.Size
		}
		if offset != size {
			t.Fatalf("size %d: covered %d", size, offset)
		}
		if size == 128*utils.MB && len(parts) != 16 {
			t.Fatalf("128MiB has %d parts", len(parts))
		}
	}
	for _, size := range []int64{0, -1} {
		if _, err := SplitFile(size); err == nil {
			t.Fatalf("accepted invalid size %d", size)
		}
	}
}
