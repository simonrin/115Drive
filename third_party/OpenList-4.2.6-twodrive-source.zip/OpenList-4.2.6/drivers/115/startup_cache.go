package _115

// TwoDrive's private instance can seed its empty memory cache from a complete
// directory + SHA1 manifest revalidated AFTER this driver started. This is a
// one-shot bootstrap, not an alternate persistent source of filesystem truth.
import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/OpenListTeam/OpenList/v4/internal/model"
	driver115 "github.com/SheltonZhu/115driver/pkg/driver"
	log "github.com/sirupsen/logrus"
)

type verifiedDirectory struct {
	Path string               `json:"path"`
	Rows []driver115.FileInfo `json:"rows"`
}

type verifiedIndex struct {
	Version      int                          `json:"version"`
	Remote       string                       `json:"remote"`
	RootID       string                       `json:"root_id"`
	Identity     string                       `json:"identity"`
	CheckedAt    float64                      `json:"checked_at"`
	TreeVerified bool                         `json:"tree_verified"`
	Dirs         map[string]verifiedDirectory `json:"dirs"`
}

type verifiedStartupCache struct {
	mu       sync.Mutex
	path     string
	started  time.Time
	modified time.Time
	size     int64
	index    *verifiedIndex
	used     map[string]bool
	disabled bool
	restored int
}

func newVerifiedStartupCache() *verifiedStartupCache {
	return &verifiedStartupCache{path: os.Getenv("TWODRIVE_VERIFIED_INDEX"), started: time.Now(), used: make(map[string]bool)}
}

func (d *Pan115) disableStartupCache() {
	c := d.startupCache
	if c == nil {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if !c.disabled && c.restored > 0 {
		log.Infof("TwoDrive startup cache restored %d directories; bootstrap closed before mutation", c.restored)
	}
	c.disabled = true
	c.index = nil
}

func (d *Pan115) restoreVerifiedDirectory(cid string, refresh bool) ([]model.Obj, bool) {
	c := d.startupCache
	if c == nil || c.path == "" || d.MountPath != "/115" || d.Remark != "Managed by TwoDrive" {
		return nil, false
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.disabled || c.used[cid] {
		return nil, false
	}
	// Explicit fresh listings and previously listed directories always retain the
	// original driver's behavior. Never resurrect a stale entry after invalidation.
	if refresh {
		c.used[cid] = true
		return nil, false
	}
	st, err := os.Stat(c.path)
	if err != nil || st.Size() > 64*1024*1024 {
		return nil, false
	}
	if c.index == nil || st.ModTime() != c.modified || st.Size() != c.size {
		data, err := os.ReadFile(c.path)
		if err != nil {
			return nil, false
		}
		var idx verifiedIndex
		if json.Unmarshal(data, &idx) != nil {
			return nil, false
		}
		c.index = &idx
		c.modified, c.size = st.ModTime(), st.Size()
	}
	idx := c.index
	identity := sha256.Sum256([]byte(fmt.Sprint(d.Storage.ID) + d.Cookie))
	checked := time.Unix(0, int64(idx.CheckedAt*1e9))
	if idx.Version != 2 || idx.Remote != "cloud115:115Drive" || !idx.TreeVerified ||
		idx.Identity != hex.EncodeToString(identity[:]) || checked.Before(c.started) ||
		time.Since(checked) < 0 || time.Since(checked) > 120*time.Second ||
		idx.Dirs[idx.RootID].Path != "115Drive" {
		return nil, false
	}
	dir, ok := idx.Dirs[cid]
	if !ok || !(dir.Path == "115Drive" || strings.HasPrefix(dir.Path, "115Drive/")) {
		return nil, false
	}
	files := make([]model.Obj, 0, len(dir.Rows))
	names := make(map[string]bool)
	for _, row := range dir.Rows {
		name := strings.ToLower(row.Name)
		if name == "" || name == "." || name == ".." || strings.ContainsAny(name, "/\\") || names[name] {
			return nil, false
		}
		names[name] = true
		f := (&driver115.File{}).From(&row)
		if f.FileID == "" || f.ParentID != cid {
			return nil, false
		}
		if !f.IsDirectory {
			sha, err := hex.DecodeString(f.Sha1)
			if err != nil || len(sha) != 20 || f.PickCode == "" || f.Size < 0 {
				return nil, false
			}
		}
		files = append(files, &FileObj{File: *f})
	}
	c.used[cid] = true
	c.restored++
	if c.restored == 1 {
		log.Info("TwoDrive verified startup cache available")
	}
	return files, true
}
