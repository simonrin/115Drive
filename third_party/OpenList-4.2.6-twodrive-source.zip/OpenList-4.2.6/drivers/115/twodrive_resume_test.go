package _115

import (
	"bytes"
	"context"
	"crypto/md5"
	"crypto/sha1"
	"encoding/hex"
	"errors"
	"io"
	"testing"

	resume "github.com/OpenListTeam/OpenList/v4/internal/twodrive_resume"
	driver115 "github.com/SheltonZhu/115driver/pkg/driver"
	"github.com/aliyun/aliyun-oss-go-sdk/oss"
)

type fakeMultipart struct {
	parts     []oss.UploadedPart
	sent      int64
	failPart  int
	loseACK   bool
	initCount int
	listError error
}

func TestTwoDriveProductionUserAgent(t *testing.T) {
	for _, ua := range []string{"TwoDrive/test", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TwoDrive/1234"} {
		if !twoDriveUserAgent(ua) {
			t.Fatal("managed client not recognized", ua)
		}
	}
	if twoDriveUserAgent("rclone/v1.75.1") {
		t.Fatal("unmanaged client recognized")
	}
}

func (b *fakeMultipart) Initiate(_ context.Context, p *driver115.UploadOSSParams) (oss.InitiateMultipartUploadResult, error) {
	b.initCount++
	b.parts = nil
	return oss.InitiateMultipartUploadResult{UploadID: "session", Bucket: p.Bucket, Key: p.Object}, nil
}
func (b *fakeMultipart) List(context.Context, oss.InitiateMultipartUploadResult) ([]oss.UploadedPart, error) {
	return b.parts, b.listError
}
func (b *fakeMultipart) Upload(_ context.Context, _ oss.InitiateMultipartUploadResult, _ *driver115.UploadOSSParams, r io.Reader, n int64, num int) (oss.UploadPart, error) {
	if num == b.failPart && !b.loseACK {
		return oss.UploadPart{}, errors.New("interrupted")
	}
	data, err := io.ReadAll(r)
	if err != nil {
		return oss.UploadPart{}, err
	}
	b.sent += int64(len(data))
	sum := md5.Sum(data)
	part := oss.UploadPart{PartNumber: num, ETag: hex.EncodeToString(sum[:])}
	b.parts = append(b.parts, oss.UploadedPart{PartNumber: num, ETag: part.ETag, Size: int(n)})
	if num == b.failPart {
		return oss.UploadPart{}, errors.New("lost acknowledgement")
	}
	return part, nil
}
func (b *fakeMultipart) Complete(_ context.Context, _ oss.InitiateMultipartUploadResult, _ *driver115.UploadOSSParams, parts []oss.UploadPart) (*UploadResult, error) {
	if len(parts) != len(b.parts) {
		return nil, errors.New("wrong completion parts")
	}
	return &UploadResult{}, nil
}

func TestTwoDriveUploadRestartsReuseAcknowledgedAndAmbiguousParts(t *testing.T) {
	for _, ambiguous := range []bool{false, true} {
		t.Run(map[bool]string{false: "before-part", true: "lost-ack"}[ambiguous], func(t *testing.T) {
			dir := t.TempDir()
			s, _ := resume.New(dir)
			data := bytes.Repeat([]byte("abcdefghijklmnop"), 2<<20) // 32 MiB / four parts.
			h := sha1.Sum(data)
			hash := hex.EncodeToString(h[:])
			key := resume.Key("account", "directory", "name", hash)
			backend := &fakeMultipart{failPart: 3, loseACK: ambiguous}
			init := func() (*driver115.UploadOSSParams, *UploadResult, error) {
				return &driver115.UploadOSSParams{Bucket: "bucket", Object: "object"}, nil, nil
			}
			_, err := runMultipart(context.Background(), s, key, hash, int64(len(data)), bytes.NewReader(data), backend, init, func(float64) {})
			if err == nil {
				t.Fatal("expected interruption")
			}
			already := backend.sent
			s.Close()
			s, err = resume.New(dir)
			if err != nil {
				t.Fatal(err)
			}
			defer s.Close()
			backend.failPart = 0
			backend.sent = 0
			_, err = runMultipart(context.Background(), s, key, hash, int64(len(data)), bytes.NewReader(data), backend, init, func(float64) {})
			if err != nil {
				t.Fatal(err)
			}
			if backend.sent != int64(len(data))-already || backend.initCount != 1 {
				t.Fatal("reuploaded parts", backend.sent, already, backend.initCount)
			}
		})
	}
}

func TestTwoDriveUploadRefusesChangedPartsAndTransientFailure(t *testing.T) {
	for _, mode := range []string{"changed", "offline", "expired"} {
		t.Run(mode, func(t *testing.T) {
			s, _ := resume.New(t.TempDir())
			defer s.Close()
			data := make([]byte, 16<<20)
			h := sha1.Sum(data)
			hash := hex.EncodeToString(h[:])
			key := resume.Key(hash)
			b := &fakeMultipart{failPart: 2}
			init := func() (*driver115.UploadOSSParams, *UploadResult, error) {
				return &driver115.UploadOSSParams{Bucket: "bucket", Object: "object"}, nil, nil
			}
			runMultipart(context.Background(), s, key, hash, int64(len(data)), bytes.NewReader(data), b, init, func(float64) {})
			b.failPart = 0
			b.sent = 0
			switch mode {
			case "changed":
				b.parts[0].ETag = "wrong"
			case "offline":
				b.listError = errors.New("network unavailable")
			case "expired":
				b.listError = oss.ServiceError{Code: "NoSuchUpload"}
			}
			_, err := runMultipart(context.Background(), s, key, hash, int64(len(data)), bytes.NewReader(data), b, init, func(float64) {})
			if mode == "expired" {
				if err != nil || b.initCount != 2 || b.sent != int64(len(data)) {
					t.Fatal("expiry fallback failed", err)
				}
			} else if err == nil || b.sent != 0 || b.initCount != 1 {
				t.Fatal("unsafe restart", err, b.sent)
			}
		})
	}
}
