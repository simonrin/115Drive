package ec115

// Optional real-service A/B: random, never-uploaded content, upload-init only.
// No OSS transfer and no response to a content challenge: no file is committed.
import (
	"bytes"
	"crypto/aes"
	"crypto/elliptic"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"io"
	"math/big"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"
)

func shortSecretFixture(t *testing.T) (*EcdhCipher, []byte) {
	t.Helper()
	curve := elliptic.P224()
	rx := new(big.Int).SetBytes(remotePubKey[:28])
	ry := new(big.Int).SetBytes(remotePubKey[28:])
	for n := int64(1); n < 10000; n++ {
		scalar := big.NewInt(n).Bytes()
		shared, _ := curve.ScalarMult(rx, ry, scalar)
		if len(shared.Bytes()) != 27 {
			continue
		}
		x, y := curve.ScalarBaseMult(scalar)
		public := make([]byte, 30)
		public[0], public[1] = 29, 2+byte(y.Bit(0))
		x.FillBytes(public[2:])
		secret := shared.FillBytes(make([]byte, 28))
		return &EcdhCipher{key: secret[:16], iv: secret[12:], pubKey: public}, shared.Bytes()
	}
	t.Fatal("short secret fixture not found")
	return nil, nil
}

func TestTwoDriveLiveHandshakeAB(t *testing.T) {
	filename := os.Getenv("TWODRIVE_HANDSHAKE_PROBE")
	if filename == "" {
		t.Skip("explicit live probe only")
	}
	raw, err := os.ReadFile(filename)
	if err != nil {
		t.Fatal(err)
	}
	var info map[string]string
	if err := json.Unmarshal(raw, &info); err != nil {
		t.Fatal(err)
	}
	fixed, short := shortSecretFixture(t)
	legacy := &EcdhCipher{key: short[:aes.BlockSize], iv: short[len(short)-aes.BlockSize:], pubKey: fixed.pubKey}
	data := make([]byte, 1024*1024)
	if _, err := rand.Read(data); err != nil {
		t.Fatal(err)
	}
	digest := sha1.Sum(data)
	fileid := strings.ToUpper(hex.EncodeToString(digest[:]))
	target := "U_1_" + info["root"]
	hash := sha1.Sum([]byte(info["userid"] + fileid + target + "0"))
	sig := sha1.Sum([]byte(info["userkey"] + hex.EncodeToString(hash[:]) + "000000"))
	client := &http.Client{Timeout: 30 * time.Second, Transport: &http.Transport{Proxy: nil}}
	for _, trial := range []struct {
		name   string
		cipher *EcdhCipher
		good   bool
	}{
		{"legacy_short_secret", legacy, false}, {"fixed_padded_secret", fixed, true},
	} {
		stamp := time.Now().UnixMilli()
		ts := strconv.FormatInt(stamp, 10)
		uidmd5 := md5.Sum([]byte(info["userid"]))
		token := md5.Sum([]byte("Qclm8MGWUv59TnrR0XPg" + fileid + strconv.Itoa(len(data)) + info["userid"] + ts + hex.EncodeToString(uidmd5[:]) + "35.6.0.3"))
		form := url.Values{"appid": {"0"}, "appversion": {"35.6.0.3"}, "userid": {info["userid"]},
			"filename": {".twodrive-handshake-no-transfer.bin"}, "filesize": {strconv.Itoa(len(data))},
			"fileid": {fileid}, "target": {target}, "sig": {strings.ToUpper(hex.EncodeToString(sig[:]))},
			"t": {ts}, "token": {hex.EncodeToString(token[:])}}
		body, err := trial.cipher.Encrypt([]byte(form.Encode()))
		if err != nil {
			t.Fatal(err)
		}
		k, err := trial.cipher.EncodeToken(stamp)
		if err != nil {
			t.Fatal(err)
		}
		request, err := http.NewRequest("POST", "https://uplb.115.com/4.0/initupload.php?"+url.Values{"k_ec": {k}}.Encode(), bytes.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		request.Header.Set("Cookie", info["cookie"])
		request.Header.Set("User-Agent", "Mozilla/5.0 115Browser/35.6.0.3")
		request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		response, err := client.Do(request)
		if err != nil {
			t.Fatal("request failed (details withheld)")
		}
		payload, err := io.ReadAll(io.LimitReader(response.Body, 65536))
		response.Body.Close()
		if err != nil {
			t.Fatal("response read failed")
		}
		plain, decodeErr := trial.cipher.Decrypt(payload)
		var result struct {
			Status     int `json:"status"`
			StatusCode int `json:"statuscode"`
		}
		valid := decodeErr == nil && json.Unmarshal(plain, &result) == nil
		t.Logf("%s: HTTP %d, response_bytes=%d, decoded=%v, status=%d, statuscode=%d", trial.name, response.StatusCode, len(payload), valid, result.Status, result.StatusCode)
		if decodeErr != nil {
			t.Logf("decode_error=%v", decodeErr)
		}
		if trial.good && (!valid || (result.Status != 1 && result.Status != 7)) {
			t.Fatal("fixed handshake did not reach non-committing upload stage")
		}
		if !trial.good && valid {
			t.Fatal("legacy unexpectedly decoded; hypothesis not reproduced")
		}
		time.Sleep(time.Second)
	}
}
