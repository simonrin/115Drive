package ec115

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/elliptic"
	"encoding/binary"
	"github.com/pierrec/lz4/v4"
	"math/big"
	"testing"
)

func TestTwoDriveFixedWidthSecret(t *testing.T) {
	curve := elliptic.P224()
	rx, ry := new(big.Int).SetBytes(remotePubKey[:28]), new(big.Int).SetBytes(remotePubKey[28:])
	short, regular := 0, 0
	for n := int64(1); n <= 1024; n++ {
		scalar := big.NewInt(n).FillBytes(make([]byte, 28))
		shared, _ := curve.ScalarMult(rx, ry, scalar)
		expected := shared.FillBytes(make([]byte, 28))
		randomInput := append([]byte(nil), scalar...)
		randomInput[1] ^= 0x42 // elliptic.GenerateKey's sampling transform
		c, err := newEcdhCipher(bytes.NewReader(randomInput))
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(c.key, expected[:16]) || !bytes.Equal(c.iv, expected[12:]) {
			t.Fatalf("scalar %d derives shifted AES material (%d-byte integer)", n, len(shared.Bytes()))
		}
		if len(shared.Bytes()) < 28 {
			short++
		} else {
			regular++
		}
	}
	if short == 0 || regular == 0 {
		t.Fatal("test did not cover both leading-zero and ordinary secrets")
	}
	t.Logf("validated %d short and %d ordinary secrets", short, regular)
}

func TestTwoDriveRandomFailureReturnsError(t *testing.T) {
	if _, err := newEcdhCipher(bytes.NewReader(nil)); err == nil {
		t.Fatal("accepted failed random source")
	}
}

func TestTwoDriveResponseBoundsAndRoundTrip(t *testing.T) {
	c, _ := shortSecretFixture(t)
	for _, raw := range [][]byte{nil, {}, {1}, make([]byte, 15), make([]byte, 144)} {
		if _, err := c.Decrypt(raw); err == nil {
			t.Fatal("accepted invalid response")
		}
	}
	plain := bytes.Repeat([]byte(`{"status":1,"statuscode":0}`), 20)
	compressed := make([]byte, lz4.CompressBlockBound(len(plain)))
	n, err := lz4.CompressBlock(plain, compressed, nil)
	if err != nil || n == 0 {
		t.Fatal("compression fixture failed")
	}
	framed := make([]byte, ((n+2+15)/16)*16)
	binary.LittleEndian.PutUint16(framed, uint16(n))
	copy(framed[2:], compressed[:n])
	block, _ := aes.NewCipher(c.key)
	encoded := make([]byte, len(framed))
	cipher.NewCBCEncrypter(block, c.iv).CryptBlocks(encoded, framed)
	// Match the server's trailing bytes, which are outside its AES framing.
	decoded, err := c.Decrypt(append(encoded, 1, 2, 3, 4))
	if err != nil || !bytes.Equal(decoded, plain) {
		t.Fatal("valid framed response did not decode")
	}
}
